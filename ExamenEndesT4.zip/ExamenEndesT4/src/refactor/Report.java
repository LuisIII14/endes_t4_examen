package refactor;

/*
Extraer la impresión del título y conclusión en sus propios métodos.
 */
class Report {

    void printReport(String reporte, String conclusion) {
        // imprimir título
        imprimirReporte(reporte);

        // contenido del reporte
        System.out.println("Contenido 1...");
        System.out.println("Contenido 2...");
        // más contenido...

        // imprimir conclusión
        imprimirConclusion(conclusion);
    }
    void imprimirReporte(String reporte){
        System.out.println(reporte);
    }
    void imprimirConclusion(String conclusion){
        System.out.println(conclusion);
    }
}