package javadoc;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase Gestor personal Una clase que gestiona las acciones realizdas sobre el
 * personal empleado
 *
 * @author Luis Iturrioz
 * @version 0.1, 23/02/2024
 */
public class GestorPersonal {

    /**
     * Lista de empleados Una lista con los empleados
     */
    private List<Empleado> empleados;

    public GestorPersonal() {
        empleados = new ArrayList<>();
    }

    /**
     * Metodo de contratar Este metodo añade empleados a la lista de empleados
     *
     * @param empleado
     * @see javadoc.GestorPersonal#contratar(javadoc.Empleado)
     */
    public void contratar(Empleado empleado) {
        empleados.add(empleado);
    }

    /**
     * Metodo para despedir Borra de la lista al empleado segun su id
     *
     * @param id
     * @return lista sin el empleado de la id que se introduce
     * @see javadoc.GestorPersonal#despedir(java.lang.String)
     */
    public boolean despedir(String id) {
        return empleados.removeIf(e -> e.getId().equals(id));
    }

    /**
     * Cambia el sueldo de un empleado Comprueba con la id cual es el empleado
     * al que tenemos que cambiar el sueldo y lo modifica
     * @param id
     * @param nuevoSueldo
     * @see javadoc.GestorPersonal#cambiarSueldo(java.lang.String, double) 
     */
    public boolean cambiarSueldo(String id, double nuevoSueldo) {
        for (Empleado empleado : empleados) {
            if (empleado.getId().equals(id)) {
                empleado.setSueldo(nuevoSueldo);
                return true;
            }
        }
        return false;
    }
    
/**
     * Geter de Nombre 
     * Obtiene la variable nombre
     
     * @return lista de los empleados
     * @see javadoc.GestorPersonal#getEmpleados() 
     */
    public List<Empleado> getEmpleados() {
        return new ArrayList<>(empleados);
    }
}
