package refactor;

/*
Tarea: Renombrar "s" e "y" a nombres más descriptivos.
 */

public class Employee {
    int salarioAnual;
    int years;

    int calculateSalary() {
        return salarioAnual * years;
    }
}