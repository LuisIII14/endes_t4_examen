package javadoc;

/**
 * Clase para empleados. <br>
 * Es una clase que contienela información de los empleados.
 *
 * @author Luis Iturrioz
 * @version 0.1, 23/02/2024
 */
public class Empleado {
    // Atributos de la clase

    /**
     * Nombre.<br>
     * Esta variable almacena el nombre del empleado.<br>
     * String.
     */
    private String nombre;

    /**
     * Id.<br>
     * Este atributo contiene el identificador de cada empleado.<br>
     * String
     */
    private String id;

    /**
     * Sueldo.<br>
     * El valor del sueldo de cada empleado.<br>
     * Double
     */
    private double sueldo;

    /**
     * Constructor de empleado.<br>
     * Constructor de empleado con todas sus variables.
     *
     * @param nombre
     * @param id
     * @param sueldo
     * @see javadoc.Empleado#Empleado()
     */
    public Empleado(String nombre, String id, double sueldo) {
        this.nombre = nombre;
        this.id = id;
        this.sueldo = sueldo;
    }

    /**
     * Geter de Nombre.<br>
     * Obtiene la variable nombre.
     *
     * @return nombre
     * @see javadoc.Empleado#getNombre()
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Seter de Nombre.<br>
     * Pone la variable nombre.
     *
     * @param nombre
     * @see javadoc.Empleado#setNombre(java.lang.String)
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Geter de Id.<br>
     * Obtiene la variable id.
     *
     * @return id
     * @see javadoc.Empleado#getgetId()
     */
    public String getId() {
        return id;
    }

    /**
     * Geter de Sueldo.<br>
     * Obtiene la variable sueldo.
     *
     * @return sueldo
     * @see javadoc.Empleado#getSueldo()
     */
    public double getSueldo() {
        return sueldo;
    }

    /**
     * Seter de Sueldo.<br>
     * Pone la variable sueldo
     *
     * @param sueldo
     * @see javadoc.Empleado#setSueldo(double sueldo)
     */
    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    /**
     * Incrementar sueldo.<br>
     * Incrementa el sueldo por una cantidad dada.
     *
     * @param incremento
     * @see javadoc.Empleado#incrementarSueldo(double incremento)
     */
    public void incrementarSueldo(double incremento) {
        this.sueldo += incremento;
    }

    @Override
    public String toString() {
        return "javadoc.Empleado{"
                + "nombre='" + nombre + '\''
                + ", id='" + id + '\''
                + ", sueldo=" + sueldo
                + '}';
    }
}
