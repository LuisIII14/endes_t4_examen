package refactor;

/*
Tarea: Refactorizar el método processOrder para utilizar un objeto
de parámetro que contenga itemName, quantity, price, y customerName.
 */

class Order {

    
private class ClaseEspecificaciones{
     String itemName;
    int quantity;
     double price;
     String customerName;
     
    public ClaseEspecificaciones(String itemName, int quantity, double price, String customerName) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.customerName = customerName;
        
    }

        public ClaseEspecificaciones() {
        }
    
}
ClaseEspecificaciones especificacion = new ClaseEspecificaciones();
    void processOrder(ClaseEspecificaciones especificacion) {
        // Procesamiento del pedido
    }
}
